export const Categories=Object.freeze({
	ELECTRICITY_PRODUCER_ID:1,
	ELECTRICITY_PRODUCER_NAME:"Electricity Producer",
	1:"Electricity Producer",
	ELECTRICITY_CONSUMER_ID:2,
	ELECTRICITY_CONSUMER_NAME:"Electricity Consumer",
	2:"Electricity Consumer",
	ELECTRICITY_STOCK_ID:3,
	ELECTRICITY_STOCK_NAME:"Electricity Stock",
	3:"Electricity Stock",
	
});