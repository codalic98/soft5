import { Component} from '@angular/core';


@Component({
  selector: 'app-admin-dso-page',
  templateUrl: './admin-dso-page.component.html',
  styleUrls: ['./admin-dso-page.component.css']
})
export class AdminDsoPageComponent {
  
 

  
}
