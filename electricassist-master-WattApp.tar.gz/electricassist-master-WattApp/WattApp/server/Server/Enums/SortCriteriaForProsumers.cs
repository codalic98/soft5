﻿namespace Server.Enums
{
    public enum SortCriteriaForProsumers
    {
        Name, 
        Consumption, 
        Production
    }
}
