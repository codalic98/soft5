﻿namespace Server.DTOs
{
    public class MonthlyEnergyConsumptionLastYear
    {
        public string Month { get; set; }
        public int Year { get; set; }
        public double EnergyUsageResult { get; set; }
    }
}
