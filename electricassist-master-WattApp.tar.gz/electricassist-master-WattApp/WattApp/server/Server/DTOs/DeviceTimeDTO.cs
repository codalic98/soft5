﻿namespace Server.DTOs
{
    public class DeviceTimeDTO
    {
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public string Duration { get; set; }
    }
}
