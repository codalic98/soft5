﻿using System.Globalization;

namespace Server.DTOs
{
    public class DeviceCategoryDTO
    {
        public long Id { get; set; }
        public string Name { get; set; }  
    }
}
