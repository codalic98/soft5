﻿namespace Server.DTOs
{
    public class CityDTO
    {
        public long Id { get; set; }
        public string Name { get; set; }
    }
}
