﻿namespace Server.Exceptions
{
    public class ParameterFormatException : Exception
    {
        public ParameterFormatException(String message) : base(message) { }
    }
}
